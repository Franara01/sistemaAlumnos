package service;

import DAO.DAOAlumno;
import DAO.DAOCurso;
import DAO.DAOException;
import entidades.Alumno;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ServiceAlumno {
    private DAOAlumno daoAlumno;

    public ServiceAlumno() {
        DAOAlumno daoAlumno = new DAOAlumno();
        this.daoAlumno = daoAlumno;
    }

    public void guardar(int id) throws ServiceException {
        try {
            daoAlumno.guardar(id);
        } catch (DAOException e) {
            System.out.println(e.getMessage());
        }
    }

    public void modificar(int id, Alumno nuevoAlumno) throws ServiceException {
        try {
            daoAlumno.modificar(id, nuevoAlumno);
        } catch (DAOException e) {
            System.out.println(e.getMessage());
        }
    }

    public void eliminar(int id) throws ServiceException {
        try {
            daoAlumno.eliminar(id);
        } catch (DAOException e) {
            System.out.println(e.getMessage());
        }
    }

    public Alumno buscar(int id) throws ServiceException {
        Alumno buscarAlumno = new Alumno();
        try {
            buscarAlumno = daoAlumno.buscar(id);
            return buscarAlumno;
        } catch (DAOException e) {
            System.out.println(e);
        }
        return buscarAlumno;
    }

    public ArrayList<Alumno> buscarTodos() throws DAOException {
        ArrayList<Alumno> listaAlumnos = null;
        try {
            listaAlumnos = daoAlumno.buscarTodos();
        } catch (DAOException e) {
            System.out.println(e.getMessage());
        }
        return listaAlumnos;
    }

    public Alumno buscarAlumnoYCursos(int id) throws ServiceException {
        Alumno buscarAlumno = new Alumno();
        try {
            buscarAlumno = daoAlumno.buscarAlumnoYCursos(id);
            return buscarAlumno;
        } catch (DAOException e) {
            System.out.println(e);
        }
        return buscarAlumno;
    }

    public Map<String, Integer> buscarCalificaciones(int idAlumno) throws DAOException {
        Map<String, Integer> cursosConCalificaciones;
        cursosConCalificaciones = daoAlumno.buscarCalificaciones(idAlumno);
        return cursosConCalificaciones;
    }

}

