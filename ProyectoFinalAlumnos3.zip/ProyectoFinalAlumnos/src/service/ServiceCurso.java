package service;
import DAO.DAOCurso;
import DAO.DAOException;
import entidades.Alumno;
import entidades.Curso;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class ServiceCurso {
    private DAOCurso daoCurso;

    public ServiceCurso() {
        DAOCurso daoCurso = new DAOCurso();
        this.daoCurso = daoCurso;
    }

    public void guardar(int id) throws ServiceException {
        try {
            daoCurso.guardar(id);
        } catch (DAOException e) {
            System.out.println(e.getMessage());
        }
    }

    public void modificar(int id, Curso nuevoCurso) throws ServiceException {
        try {
            daoCurso.modificar(id, nuevoCurso);
        } catch (DAOException e) {
            System.out.println(e.getMessage());
        }
    }

    public void eliminar(int id) throws ServiceException {
        try {
            daoCurso.eliminar(id);
        } catch (DAOException e) {
            System.out.println(e.getMessage());
        }
    }

    public Curso buscar(int id) throws ServiceException {
        Curso buscarCurso = new Curso();
        try {
            buscarCurso = daoCurso.buscar(id);
        } catch (DAOException e) {
            System.out.println(e.getMessage());
        }
        return buscarCurso;

    }

    public ArrayList<Curso> buscarTodos() throws DAOException {
        ArrayList<Curso> listaCursos = null;
        try {
            listaCursos = daoCurso.buscarTodos();
        } catch (DAOException e) {
            System.out.println(e.getMessage());
        }
        return listaCursos;
    }

    public ArrayList<Integer> buscarListaAlumnos(int idCurso) throws DAOException {
        return daoCurso.buscarListaAlumnos(idCurso);
    }
}
