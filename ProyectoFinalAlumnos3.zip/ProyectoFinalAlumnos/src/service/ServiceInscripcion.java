package service;

import DAO.*;

import java.sql.SQLException;
import java.util.ArrayList;

public class ServiceInscripcion {
    private DAOInscripcion daoInscripcion;

    public ServiceInscripcion() {
        DAOInscripcion daoInscripcion = new DAOInscripcion();
        this.daoInscripcion = daoInscripcion;
    }

    public void guardarTablaIntermedia(int idAlumno, int idCurso) throws ServiceException {
        try {
            daoInscripcion.guardarTablaIntermedia(idAlumno, idCurso);
        } catch (DAOException e) {
            throw new RuntimeException(e);
        }
    }

    public void eliminarTablaIntermedia (int idAlumno, int idCurso) throws DAOException, SQLException {
        try {
            daoInscripcion.eliminarTablaIntermedia(idAlumno, idCurso);
        } catch (DAOException e) {
            throw new DAOException(e.getMessage());
        } catch (ServiceException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean existeInscripcion (int idAlumno, int idCurso) {
        try {
            return daoInscripcion.existeInscripcion(idAlumno, idCurso);
        } catch (DAOException e) {
            throw new RuntimeException(e);
        }
    }

    public void actualizarCalificacion (int idAlumno, int idCurso, int calificacion) {
        try {
            daoInscripcion.actualizarCalificacion(idAlumno, idCurso, calificacion);
        } catch (DAOException e) {
            throw new RuntimeException(e);
        }
    }

    public void cursoAprobado (int idAlumno, int idCurso) throws DAOException {
        daoInscripcion.cursoAprobado(idAlumno, idCurso);
    }

    public void cursoDesaprobado (int idAlumno, int idCurso) throws DAOException {
        daoInscripcion.cursoDesaprobado(idAlumno, idCurso);
    }

    public ArrayList<Integer> buscarCursosAprobados (int idAlumno) throws DAOException, SQLException {
        return daoInscripcion.buscarCursosAprobados(idAlumno);
    }
}
