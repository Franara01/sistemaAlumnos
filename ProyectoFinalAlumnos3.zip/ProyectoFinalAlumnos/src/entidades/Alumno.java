package entidades;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Alumno {
    private int id;
    private String nombre;
    private String apellido;
    private int cursosAprobados;
    private int limiteCursos = 3;
    private ArrayList<Curso> listaCursos;
    private Map<Curso, Integer> calificaciones;

    public Alumno() {
    }

    public Alumno(int id, String nombre, String apellido, int calificacion) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.limiteCursos = 3;
        this.listaCursos = new ArrayList<>();
        this.calificaciones = new HashMap<>();

    }

    public Alumno(int id, String nombre, String apellido) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.limiteCursos = 3;
        this.listaCursos = new ArrayList<>();
        this.calificaciones = new HashMap<>();
        this.cursosAprobados = 0;
    }

    public Alumno(int id, String nombre, String apellido, ArrayList<Curso> cursos) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.listaCursos = cursos;
        this.calificaciones = new HashMap<>();
        this.cursosAprobados = 0;
    }

    public Alumno(int id, String apellido) {
        this.id = id;
        this.apellido = apellido;
    }


    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public ArrayList<Curso> getListaCursos() {
        return listaCursos;
    }

    public int getLimiteCursos() {
        return limiteCursos;
    }

    public int getCursosAprobados() {
        return cursosAprobados;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setListaCursos(ArrayList<Curso> listaCursos) {
        this.listaCursos = listaCursos;
    }

    @Override
    public String toString() {
        return " ID: " + id +
                " || Nombre: " + nombre +
                " || Apellido: " + apellido +
                " \n Lista de cursos " + getListaCursos();
    }
}
