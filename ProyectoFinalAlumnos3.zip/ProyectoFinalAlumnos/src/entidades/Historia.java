package entidades;

public class Historia extends Curso {
    public Historia(int id, String nombre, int cupos, int precio, int notaAprobacion) {
        super(id, nombre, cupos, precio, notaAprobacion);
    }
}
