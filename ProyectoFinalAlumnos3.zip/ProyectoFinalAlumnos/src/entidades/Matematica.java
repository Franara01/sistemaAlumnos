package entidades;

public class Matematica extends Curso{

    public Matematica(int id, String nombre, int cupos, int precio, int notaAprobacion) {
        super(id, nombre, cupos, precio, notaAprobacion);
    }
}
