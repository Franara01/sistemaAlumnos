package entidades;

import DAO.DAOAlumno;
import DAO.DAOCurso;
import DAO.DAOException;
import service.ServiceAlumno;
import service.ServiceCurso;
import service.ServiceException;
import service.ServiceInscripcion;

import java.util.ArrayList;
import java.util.Map;

public class Escuela {
    private String nombre;
    private static ArrayList<Alumno> listaAlumnos;
    private static ArrayList<Curso> listaCursos;


    public Escuela(String nombre) throws DAOException {
        this.nombre = nombre;
        this.listaAlumnos = new ArrayList<>();
        this.listaCursos = new ArrayList<>();
    }

    public static void crearAlumno(int id, String nombre, String apellido) {
        Alumno nuevoAlumno = new Alumno(id, nombre, apellido);
        listaAlumnos.add(nuevoAlumno);
    }

    public static Curso crearCurso(int id, String tipoCurso, String nombre, int cupos, int precio, int notaAprobacion) {
        Curso nuevoCurso = null;
        switch (tipoCurso.toLowerCase()) {
            case "historia":
                nuevoCurso = new Historia(id, nombre, cupos, precio, notaAprobacion);
                listaCursos.add(nuevoCurso);
                return nuevoCurso;
            case "matematica":
                nuevoCurso = new Matematica(id, nombre, cupos, precio, notaAprobacion);
                listaCursos.add(nuevoCurso);
                return nuevoCurso;
            default:
                throw new IllegalArgumentException("Por favor, ingrese un tipo de curso válido");
        }
    }

    public static Alumno buscarAlumnoPorId(int id) {
        for (Alumno alumno : listaAlumnos) {
            if (alumno.getId() == id) {
                return alumno;
            }
        } return null;
    }

    public static Curso buscarCursoPorId(int id) {
        for (Curso curso : listaCursos) {
            if (curso.getIdCurso() == id) {
                return curso;
            }
        } return null;
    }

    public static int sePuedeInscribir (Alumno alumno, Curso curso, boolean inscripcion, int cupos, int cantidadDeAlumnosInscriptos, int cantidadDeCursosDelAlumno, int cursosAprobados) {
        while (true) {
            if (existenAlumnoYCurso(alumno, curso)) {
                if (noExisteInscripcion(inscripcion)) {
                    if (hayCupos(cupos, cantidadDeAlumnosInscriptos)) {
                        cantidadDeCursosDelAlumno = cantidadDeCursosDelAlumno - cursosAprobados;
                        if (limiteCursos(alumno, cantidadDeCursosDelAlumno)) {
                            return 4;
                        } else return 3;
                    } else return 2;
                } else return 1;
            } else return 0;
        }
    }

    public static boolean existenAlumnoYCurso (Alumno alumno, Curso curso) {
        if (alumno != null && curso != null) {
            return true;
        } return false;
    }

    public static boolean noExisteInscripcion (boolean inscripcion) {
        if (!inscripcion) {
            return true;
        } return false;
    }

    public static boolean hayCupos (int cupos, int cantidadDeAlumnosInscriptos) {
        if (cupos - cantidadDeAlumnosInscriptos > 0) {
            return true;
        } return false;
    }

    public static boolean limiteCursos (Alumno alumno, int cantidadDeCursosALosQueSeInscribio) {
        if (alumno.getLimiteCursos() - cantidadDeCursosALosQueSeInscribio > 0) {
            return true;
        } return false;
    }

    public static ArrayList<Curso> getListaCursos() {
        return listaCursos;
    }

    @Override
    public String toString() {
        return  "Nombre de la escuela: " + nombre + "\n" +
                "Lista de alumnos: " + listaAlumnos + "\n" +
                "Lista de cursos: " + listaCursos;
    }
}
