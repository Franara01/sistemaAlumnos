package entidades;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Curso {
    private int id;
    private String nombre;
    private int cupos;
    private double precio;
    private int notaAprobacion;
    private ArrayList<Alumno> listaAlumnos;


    public Curso(int id, String nombre, int cupos, int precio, int notaAprobacion) {
        this.id = id;
        this.nombre = nombre;
        this.cupos = cupos;
        this.precio = precio;
        this.notaAprobacion = notaAprobacion;
        this.listaAlumnos = new ArrayList<>();
    }

    public Curso(int id) {
        this.id = id;
    }

    public Curso(){
    }

    public int getIdCurso() {
        return id;
    }
    public ArrayList<Alumno> getListaAlumnos() {
        return listaAlumnos;
    }
    public void setListaAlumnos(ArrayList<Alumno> listaAlumnos) {
        this.listaAlumnos = listaAlumnos;
    }

    public int getPrecio() {
        return (int) precio;
    }

    public int getCupos() {
        return cupos;
    }

    public String getNombre() {
        return nombre;
    }

    public int getId() {
        return id;
    }
    public int getNotaAprobacion() {
        return notaAprobacion;
    }
    public void setIdCurso(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCupos(int cupos) {
        this.cupos = cupos;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    public void setNotaAprobacion(int notaAprobacion) {
        this.notaAprobacion = notaAprobacion;
    }

    @Override
    public String toString() {
        return  "\n ID: " + id +
                "\n Nombre: " + nombre;
    }
}
