import DAO.DAOAlumno;
import DAO.DAOCurso;
import DAO.DAOException;
import DAO.DAOInscripcion;
import entidades.Alumno;
import entidades.Curso;
import entidades.Escuela;
import gui.PanelManager;
import service.ServiceAlumno;
import service.ServiceCurso;
import service.ServiceException;
import service.ServiceInscripcion;

import java.security.Provider;
import java.sql.SQLException;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) throws ServiceException, DAOException, SQLException {
        Escuela escuela = new Escuela("UP");
        PanelManager panel = new PanelManager();
    }
}