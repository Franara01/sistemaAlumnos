package DAO;
import entidades.Alumno;
import entidades.Escuela;
import entidades.Curso;

import java.sql.*;
import java.util.ArrayList;

public class DAOCurso implements IDAO<Curso> {
    private String DB_JDBC_DRIVER = "org.h2.Driver";
    private String DB_URL = "jdbc:h2:~/ProyectoFinalDB";
    private String DB_USER = "";
    private String DB_PASSWORD = "";


    @Override
    public void guardar(int id) throws DAOException {
        Curso curso = Escuela.buscarCursoPorId(id);
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);


            // Debes modificar la sentencia SQL para insertar en la tabla "Curso"
            preparedStatement = connection.prepareStatement("INSERT INTO Curso (IDCurso, Nombre, Precio, Cupos, NotaAprobacion) VALUES (?, ?, ?, ?, ?)");
            preparedStatement.setInt(1, curso.getIdCurso());
            preparedStatement.setString(2, curso.getNombre());
            preparedStatement.setDouble(3, curso.getPrecio());
            preparedStatement.setInt(4, curso.getCupos());
            preparedStatement.setInt(5, curso.getNotaAprobacion());

            preparedStatement.executeUpdate();
        } catch (ClassNotFoundException | SQLException e) {
            throw new DAOException("Error al insertar el curso. Puede que el curso ya haya sido insertado.");
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                    connection.close();
                }
            } catch (SQLException e) {
                throw new DAOException("No se pudo conectar");
            }
        }
    }


    @Override
    public void modificar(int idCurso, Curso nuevoCurso) throws DAOException { // Hacer el botón
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("UPDATE Curso SET Nombre = ?, Precio = ?, Cupos = ?, NotaAprobacion = ? WHERE IDCurso = ?");
            preparedStatement.setString(1, nuevoCurso.getNombre());
            preparedStatement.setDouble(2, nuevoCurso.getPrecio());
            preparedStatement.setInt(3, nuevoCurso.getCupos());
            preparedStatement.setInt(4, nuevoCurso.getNotaAprobacion());
            preparedStatement.setInt(5, idCurso);

            int rowCount = preparedStatement.executeUpdate();

            if (rowCount == 0) {
                throw new DAOException("No se encontró ningún registro para modificar con el ID de curso: " + idCurso);
            }
        } catch (ClassNotFoundException | SQLException e) {
            throw new DAOException("Error al modificar el curso", e);
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                throw new DAOException("Error al cerrar la conexión", e);
            }
        }
    }


    @Override
    public void eliminar(int idCurso) throws DAOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            preparedStatement = connection.prepareStatement("DELETE FROM Curso WHERE IDCurso = ?");
            preparedStatement.setInt(1, idCurso);

            int rowCount = preparedStatement.executeUpdate();
            if (rowCount == 0) {
                throw new DAOException("No se encontró ningún registro para eliminar con el ID de curso: " + idCurso);
            }
        } catch (ClassNotFoundException | SQLException e) {
            throw new DAOException("Error al eliminar el curso", e);
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                throw new DAOException("Error al cerrar la conexión", e);
            }
        }
    }


    @Override
    public Curso buscar(int idCurso) throws DAOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        Curso curso = null;

        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("SELECT * FROM Curso WHERE IDCurso = ?");
            preparedStatement.setInt(1, idCurso);
            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
                curso = new Curso(); // Asignar el objeto a "curso" en lugar de "cursoNuevo"
                curso.setIdCurso(rs.getInt("IDCurso"));
                curso.setNombre(rs.getString("Nombre"));
                curso.setPrecio(rs.getDouble("Precio"));
                curso.setCupos(rs.getInt("Cupos"));
                curso.setNotaAprobacion(rs.getInt("NotaAprobacion"));
            }

        } catch (ClassNotFoundException | SQLException e) {
            throw new DAOException("No se encuentra el curso", e);
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                throw new DAOException("Error al cerrar la conexión", e);
            }
        }
        return curso;
    }


    @Override
    public ArrayList<Curso> buscarTodos() throws DAOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        ArrayList<Curso> listaCursos = new ArrayList<>();

        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("SELECT * FROM Curso");
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Curso curso = new Curso();
                curso.setIdCurso(resultSet.getInt("IDCurso"));
                curso.setNombre(resultSet.getString("Nombre"));
                curso.setPrecio(resultSet.getDouble("Precio"));
                curso.setCupos(resultSet.getInt("Cupos"));
                curso.setNotaAprobacion(resultSet.getInt("NotaAprobacion"));
                listaCursos.add(curso);
            }
        } catch (ClassNotFoundException | SQLException e) {
            throw new DAOException("Error al buscar todos los cursos", e);
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                throw new DAOException("Error al cerrar la conexión", e);
            }
        }
        return listaCursos;
    }

    public ArrayList<Integer> buscarListaAlumnos(int idCurso) throws DAOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ArrayList<Integer> idsAlumnos = new ArrayList<>();

        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("SELECT a.ID FROM curso c INNER JOIN inscripcion i ON c.IDcurso = i.IDcurso INNER JOIN alumno a ON i.IDalumno = a.ID WHERE c.IDcurso = ?");
            preparedStatement.setInt(1, idCurso);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int idAlumno = rs.getInt("ID");
                idsAlumnos.add(idAlumno);
            }

            connection.close();
            return idsAlumnos;

        } catch (ClassNotFoundException | SQLException e) {
            throw new DAOException("Error al obtener los IDs de los alumnos en el curso", e);
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                throw new DAOException("Error al cerrar la conexión", e);
            }
        }
    }
}
