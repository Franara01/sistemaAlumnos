package DAO;

import entidades.Alumno;
import entidades.Curso;
import entidades.Escuela;
import service.ServiceAlumno;
import service.ServiceCurso;
import service.ServiceException;

import java.sql.*;
import java.util.ArrayList;

public class DAOInscripcion implements IDAO<Alumno> {
    private String DB_JDBC_DRIVER = "org.h2.Driver";
    private String DB_URL = "jdbc:h2:~/ProyectoFinalDB";
    private String DB_USER = "";
    private String DB_PASSWORD = "";

    @Override
    public void guardar(int id) throws DAOException { }

    @Override
    public void modificar(int id, Alumno elemento) throws DAOException { }

    @Override
    public void eliminar(int id) throws DAOException { }

    @Override
    public Alumno buscar(int id) throws DAOException {
        return null;
    }

    @Override
    public ArrayList<Alumno> buscarTodos() throws DAOException {
        return null;
    }

    public void guardarTablaIntermedia(int idAlumno, int idCurso) throws DAOException {
        ServiceAlumno serviceAlumno = new ServiceAlumno();
        ServiceCurso serviceCurso = new ServiceCurso();
        try {
            Alumno alumno = serviceAlumno.buscar(idAlumno);
            Curso curso = serviceCurso.buscar(idCurso);
            Connection connection = null;
            PreparedStatement preparedStatement = null;
            try {
                Class.forName(DB_JDBC_DRIVER);
                connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                preparedStatement = connection.prepareStatement("INSERT INTO Inscripcion VALUES (?, ?, null, false)"); // Case sensitive
                preparedStatement.setInt(1, alumno.getId());
                preparedStatement.setInt(2, curso.getIdCurso());
                preparedStatement.executeUpdate();
            } catch (SQLException | ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
            finally {
                try {
                    if (preparedStatement != null) {
                        preparedStatement.close();
                    }
                } catch (SQLException e) {
                    throw new DAOException("No se pudo conectar");
                }
            }
        } catch (ServiceException d) {
            System.out.println(d.getMessage());
        }
    }

    public void eliminarTablaIntermedia (int idAlumno, int idCurso) throws DAOException, SQLException, ServiceException {
        ServiceAlumno serviceAlumno = new ServiceAlumno();
        ServiceCurso serviceCurso = new ServiceCurso();
        try {
            Alumno alumno = serviceAlumno.buscar(idAlumno);
            Curso curso = serviceCurso.buscar(idCurso);
            Connection connection = null;
            PreparedStatement preparedStatement = null;
            try {
                Class.forName(DB_JDBC_DRIVER);
                connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                preparedStatement = connection.prepareStatement("DELETE FROM Inscripcion WHERE IDALUMNO = ? AND IDCURSO = ?");
                preparedStatement.setInt(1, alumno.getId());
                preparedStatement.setInt(2, curso.getIdCurso());
                int rowCount = preparedStatement.executeUpdate();
                if (rowCount == 0) {
                    throw new DAOException("No se encontró ningún registro para eliminar con ese ID");
                }
            }  catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            } finally {
                try {
                    if (preparedStatement != null) {
                        preparedStatement.close();
                    }
                    if (connection != null) {
                        connection.close();
                    }
                } catch (SQLException e) {
                    throw new DAOException("Error al cerrar la conexión", e);
                }
            }
        } catch (ServiceException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean existeInscripcion(int idAlumno, int idCurso) throws DAOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        boolean existeAlumno = false;

        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("SELECT idalumno FROM Inscripcion WHERE idcurso = ? AND idalumno = ?");
            preparedStatement.setInt(1, idCurso);
            preparedStatement.setInt(2, idAlumno);
            resultSet = preparedStatement.executeQuery();
            existeAlumno = resultSet.next(); // Si hay resultados, el alumno está inscrito
        } catch (SQLException | ClassNotFoundException e) {
            throw new DAOException("Error al verificar la inscripción del alumno en el curso", e);
        } finally {
                try {
                    if (resultSet != null) {
                        resultSet.close();
                    }
                    if (preparedStatement != null) {
                        preparedStatement.close();
                    }
                    if (connection != null) {
                        connection.close();
                    }
                } catch (SQLException e) {
                    throw new DAOException("Error al cerrar la conexión");
                }
            }
            return existeAlumno;
        }

    public void actualizarCalificacion(int idAlumno, int idCurso, double calificacion) throws DAOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            preparedStatement = connection.prepareStatement("UPDATE Inscripcion SET calificacion = ? WHERE idalumno = ? AND idcurso = ?");
            preparedStatement.setDouble(1, calificacion);
            preparedStatement.setInt(2, idAlumno);
            preparedStatement.setInt(3, idCurso);

            int resultSet = preparedStatement.executeUpdate();

            if (resultSet == 0) {
                throw new DAOException("No se pudo actualizar la calificación");
            }
        } catch (SQLException | ClassNotFoundException e) {
            throw new DAOException("Error al actualizar la calificación", e);
        } finally {
            {
                try {
                    if (preparedStatement != null) {
                        preparedStatement.close();
                    }
                    if (connection != null) {
                        connection.close();
                    }
                } catch (SQLException e) {
                    throw new DAOException("Error al cerrar la conexión");
                }
            }
       }
    }

    public void cursoAprobado(int idAlumno, int idCurso) throws DAOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("UPDATE Inscripcion SET aprobado = true WHERE idalumno = ? AND idcurso = ?");
            preparedStatement.setInt(1, idAlumno);
            preparedStatement.setInt(2, idCurso);

            int resultSet = preparedStatement.executeUpdate();

            if (resultSet == 0){
                throw new DAOException("No se pudo marcar el curso como aprobado");
            }
        } catch (SQLException | ClassNotFoundException e) {
            throw new DAOException("Error al marcar el curso como aprobado", e);
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                throw new DAOException("Error al cerrar la conexión");
            }
        }
    }

    public void cursoDesaprobado(int idAlumno, int idCurso) throws DAOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("UPDATE Inscripcion SET aprobado = false WHERE idalumno = ? AND idcurso = ?");
            preparedStatement.setInt(1, idAlumno);
            preparedStatement.setInt(2, idCurso);

            int resultSet = preparedStatement.executeUpdate();

            if (resultSet == 0) {
                throw new DAOException("No se pudo marcar el curso como desaprobado");
            }
        } catch (SQLException | ClassNotFoundException e) {
            throw new DAOException("Error al marcar el curso como desaprobado", e);
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                throw new DAOException("Error al cerrar la conexión");
            }
        }
    }

    public ArrayList<Integer> buscarCursosAprobados (int idAlumno) throws DAOException, SQLException {
        ArrayList<Integer> cursosAprobados = new ArrayList<>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            preparedStatement = connection.prepareStatement("SELECT idcurso FROM Inscripcion WHERE idalumno = ? AND aprobado = true");
            preparedStatement.setInt(1, idAlumno);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int idCurso = resultSet.getInt("idcurso");
                cursosAprobados.add(idCurso);
            }
        }  catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                throw new DAOException("Error al cerrar la conexión");
            }
        }
        return cursosAprobados;
    }


}
