package DAO;

import entidades.Alumno;
import entidades.Curso;
import entidades.Escuela;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DAOAlumno implements IDAO<Alumno>{

    private String DB_JDBC_DRIVER="org.h2.Driver";
    private String DB_URL = "jdbc:h2:~/ProyectoFinalDB";
    private String DB_USER = "";
    private String DB_PASSWORD = "";

    public void guardar(int id) throws DAOException {
        Alumno elemento = Escuela.buscarAlumnoPorId(id);
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try{
            Class.forName(DB_JDBC_DRIVER);
            connection= DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("INSERT INTO Alumno VALUES (?,?,?)"); // Case sensitive
            preparedStatement.setInt(1, elemento.getId());
            preparedStatement.setString(2, elemento.getNombre());
            preparedStatement.setString(3, elemento.getApellido());
            preparedStatement.executeUpdate();
        }
        catch (ClassNotFoundException | SQLException e) {
            throw new DAOException("Error al insertar. Puede que el alumno ya haya sido insertado.");
        }
        finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
            }
            catch (SQLException e) {
                throw new DAOException("No se pudo conectar");
            }
        }
    }

    public void modificar(int id, Alumno nuevoAlumno) throws DAOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("UPDATE Alumno SET nombre = ?, apellido = ? WHERE ID = ?");
            preparedStatement.setString(1, nuevoAlumno.getNombre());
            preparedStatement.setString(2, nuevoAlumno.getApellido());
            preparedStatement.setInt(3, id);
            int rowCount = preparedStatement.executeUpdate();

            if (rowCount == 0) {
                throw new DAOException("No se encontró ningún registro para modificar con el ID: " + id);
            }
        } catch (ClassNotFoundException | SQLException e) {
            throw new DAOException("Error al modificar el alumno", e);
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                throw new DAOException("Error al cerrar la conexión", e);
            }
        }
    }


    public void eliminar(int id) throws DAOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("DELETE FROM Alumno WHERE ID = ?");
            preparedStatement.setInt(1, id);
            int rowCount = preparedStatement.executeUpdate();
            if (rowCount == 0) {
                throw new DAOException("No se encontró ningún registro para eliminar con el ID: " + id);
            }
        } catch (ClassNotFoundException | SQLException e) {
            throw new DAOException("Error al eliminar el alumno", e);
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                throw new DAOException("Error al cerrar la conexión", e);
            }
        }
    }


    public Alumno buscar(int id) throws DAOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        Alumno alumno = null;
        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
            preparedStatement = connection.prepareStatement("SELECT * FROM Alumno WHERE ID=?"); // Case sensitive
            preparedStatement.setInt(1, id);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                alumno = new Alumno();
                alumno.setId(rs.getInt("ID")); // Case Sensitive
                alumno.setApellido(rs.getNString("APELLIDO")); // Case Sensitive
                alumno.setNombre(rs.getString("NOMBRE")); // Case Sensitive
                connection.close();
                return alumno;
            }
        }
        catch (ClassNotFoundException | SQLException s) {
            throw new DAOException("No se encuentra el alumno");
        }
        finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
            } catch (SQLException e) {
                throw new DAOException("Error");
            }

            }
        return alumno;
    }


    public ArrayList<Alumno> buscarTodos() throws DAOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        ArrayList<Alumno> listaAlumnos = new ArrayList<>();
        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("SELECT * FROM Alumno");
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Alumno alumno = new Alumno();
                alumno.setId(resultSet.getInt("ID"));
                alumno.setApellido(resultSet.getNString("apellido"));
                alumno.setNombre(resultSet.getString("nombre"));
                listaAlumnos.add(alumno);
            }
        } catch (ClassNotFoundException | SQLException e) {
            throw new DAOException("Error al buscar todos los alumnos", e);
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                throw new DAOException("Error al cerrar la conexión", e);
            }
        }
        return listaAlumnos;
    }

    public Alumno buscarAlumnoYCursos(int id) throws DAOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        Alumno alumno = null;
        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("SELECT a.ID AS id_alumno, a.nombre AS nombre_alumno, a.apellido AS apellido_alumno, c.idcurso, c.nombre AS nombre_curso\n" +
                    "FROM alumno a\n" +
                    "INNER JOIN inscripcion i ON a.ID = i.IDalumno\n" +
                    "INNER JOIN curso c ON i.IDcurso = c.idcurso\n" +
                    "WHERE a.ID = ?;\n");
            preparedStatement.setInt(1, id);
            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
                alumno = new Alumno();
                alumno.setId(rs.getInt("id_alumno"));
                alumno.setApellido(rs.getNString("apellido_alumno"));
                alumno.setNombre(rs.getString("nombre_alumno"));

                ArrayList<Curso> cursos = new ArrayList<>();
                do {
                    Curso curso = new Curso();
                    curso.setIdCurso(rs.getInt("idcurso"));
                    curso.setNombre(rs.getString("nombre_curso"));

                    cursos.add(curso);
                } while (rs.next());

                alumno.setListaCursos(cursos);
            }
            connection.close();
            return alumno;

        } catch (ClassNotFoundException | SQLException s) {
            throw new DAOException("Error al buscar el alumno y sus cursos");
        } finally {
        try {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            throw new DAOException("Error al cerrar la conexión", e);
        }
        }
    }

    public Map<String, Integer> buscarCalificaciones(int idAlumno) throws DAOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        Map<String, Integer> cursosConCalificaciones = new HashMap<>();

        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("SELECT c.nombre AS nombre_curso, i.calificacion FROM curso c INNER JOIN inscripcion i ON c.IDCurso = i.IDCurso WHERE i.IDAlumno = ?");
            preparedStatement.setInt(1, idAlumno);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                String nombreCurso = rs.getString("nombre_curso");
                int calificacion = rs.getInt("calificacion");
                cursosConCalificaciones.put(nombreCurso, calificacion);
            }

            connection.close();
            return cursosConCalificaciones;

        } catch (ClassNotFoundException | SQLException e) {
            throw new DAOException("Error al obtener cursos con calificaciones por alumno", e);
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                throw new DAOException("Error al cerrar la conexión", e);
            }
        }
    }


}
