package DAO;

import java.util.ArrayList;

public interface IDAO <T> {


    public void guardar(int id) throws DAOException;
    public void modificar(int id, T elemento) throws DAOException;
    public void eliminar(int id) throws DAOException;
    public T buscar(int id) throws DAOException;
    public ArrayList<T> buscarTodos() throws DAOException;


}
