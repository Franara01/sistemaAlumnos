//  COMO HAGO PARA INSCRIBIR A LOS ALUMNOS EN LOS CURSOS? A NIVEL BD

/* ME FALTA:

- MANEJAR CALIFICACIONES -- Para eso debo poder inscribir a los alumnos en los cursos.
- RECAUDACIÓN DE LOS CURSOS -- Para eso debo poder inscribir a los alumnos en los cursos.
- REPORTE DEL CURSO: ANOTADOS Y RECAUDACIÓN -- Para eso debo poder inscribir a los alumnos en los cursos.

 */


package gui;

import DAO.DAOAlumno;
import DAO.DAOCurso;
import DAO.DAOException;
import entidades.Alumno;
import entidades.Curso;
import entidades.Escuela;
import service.ServiceAlumno;
import service.ServiceCurso;
import service.ServiceException;
import service.ServiceInscripcion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class FormularioCurso extends JPanel {
    PanelManager panel;
    ServiceAlumno serviceAlumno;
    JPanel formularioCurso;
    JLabel jLabelID;
    JLabel jLabelNombre;
    JLabel jLabelCupos;
    JLabel jLabelPrecio;
    JLabel jLabelNotaAprobacion;
    JTextField jTextFieldID;
    JLabel jLabelTipoCurso;
    JTextField jTextFieldTipoCurso;
    JTextField jTextFieldNombre;
    JTextField jTextFieldCupos;
    JTextField jTextFieldPrecio;
    JTextField jTextFieldNotaAprobacion;
    JButton jButtonGuardarCurso;
    JButton jButtonPasarAAlumnos;
    JButton jButtonEliminarCurso;
    JButton jButtonMostrarTodos;
    JButton jButtonBuscarCurso;
    JButton jButtonRecaudacionTotal;
    JButton jButtonPasarAInscripcion;
    JButton jButtonModificarCurso;
    JButton jButtonRellenarDatos;
    private JButton jButtonRecaudacionDeCurso;

    public FormularioCurso(PanelManager panelManager) {
        this.panel = panelManager;
        serviceAlumno = new ServiceAlumno();
        armarFormularioCurso();
    }

    public void armarFormularioCurso() {
        formularioCurso = new JPanel();
        serviceAlumno = new ServiceAlumno();
        formularioCurso.setLayout(new GridLayout(11, 2));
        jLabelID = new JLabel("ID del curso: ");
        jTextFieldID = new JTextField(20);
        jLabelTipoCurso = new JLabel("Tipo de curso: ");
        jTextFieldTipoCurso = new JTextField(20);
        jLabelNombre = new JLabel("Nombre: ");
        jTextFieldNombre = new JTextField(20);
        jLabelCupos = new JLabel("Cupos: ");
        jTextFieldCupos = new JTextField(20);
        jLabelPrecio = new JLabel("Precio: ");
        jTextFieldPrecio = new JTextField(20);
        jLabelNotaAprobacion = new JLabel("Nota de aprobación: ");
        jTextFieldNotaAprobacion = new JTextField();
        jButtonGuardarCurso = new JButton("Crear nuevo curso");
        jButtonPasarAAlumnos = new JButton("Pasar a alumnos");
        jButtonEliminarCurso = new JButton("Eliminar curso");
        jButtonMostrarTodos = new JButton("Mostrar todos los cursos");
        jButtonBuscarCurso = new JButton("Buscar curso");
        jButtonRecaudacionTotal = new JButton("Mostrar recaudacion total de todos los cursos");
        jButtonRellenarDatos = new JButton("Rellenar datos del curso");
        jButtonModificarCurso = new JButton("Modificar curso");
        jButtonPasarAInscripcion = new JButton("Pasar a inscripción");
        jButtonRecaudacionDeCurso = new JButton("Mostrar recaudación del curso");



        formularioCurso.add(jLabelID);
        formularioCurso.add(jTextFieldID);
        formularioCurso.add(jLabelTipoCurso);
        formularioCurso.add(jTextFieldTipoCurso);
        formularioCurso.add(jLabelNombre);
        formularioCurso.add(jTextFieldNombre);
        formularioCurso.add(jLabelCupos);
        formularioCurso.add(jTextFieldCupos);
        formularioCurso.add(jLabelPrecio);
        formularioCurso.add(jTextFieldPrecio);
        formularioCurso.add(jLabelNotaAprobacion);
        formularioCurso.add(jTextFieldNotaAprobacion);

        formularioCurso.add(jButtonGuardarCurso);
        formularioCurso.add(jButtonEliminarCurso);
        formularioCurso.add(jButtonMostrarTodos);
        formularioCurso.add(jButtonBuscarCurso);
        formularioCurso.add(jButtonRecaudacionTotal);
        formularioCurso.add(jButtonRecaudacionDeCurso);
        formularioCurso.add(jButtonRellenarDatos);
        formularioCurso.add(jButtonModificarCurso);
        formularioCurso.add(jButtonPasarAAlumnos);
        formularioCurso.add(jButtonPasarAInscripcion);
        setLayout(new BorderLayout());
        add(formularioCurso, BorderLayout.CENTER);

        jButtonPasarAAlumnos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrarFormularioAlumnos();
            }
        });

        jButtonGuardarCurso.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int intID = Integer.parseInt(jTextFieldID.getText());
                    int intCupos = Integer.parseInt(jTextFieldCupos.getText());
                    int intPrecio = Integer.parseInt(jTextFieldPrecio.getText());
                    int intNotaAprobacion = Integer.parseInt(jTextFieldNotaAprobacion.getText());

                    if (Escuela.buscarCursoPorId(intID) != null) {
                        JOptionPane.showMessageDialog(null, "El curso ya existe.");
                    } else {
                        ServiceCurso serviceCurso = new ServiceCurso();
                        try {
                            Curso nuevoCurso = Escuela.crearCurso(intID, jTextFieldTipoCurso.getText(), jTextFieldNombre.getText(), intCupos, intPrecio, intNotaAprobacion);
                            try {
                                serviceCurso.guardar(nuevoCurso.getId());
                            } catch (ServiceException d) {
                                throw new ServiceException(d.getMessage());
                            }
                            JOptionPane.showMessageDialog(null, "Curso creado correctamente.");
                        } catch (IllegalArgumentException i) {
                            JOptionPane.showMessageDialog(null, "Ingrese un tipo de curso válido");
                        }
                    }
                } catch (NumberFormatException n) {
                    JOptionPane.showMessageDialog(null, "Ingrese un valor numérico en el campo ID");
                } catch (ServiceException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        jButtonEliminarCurso.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    ServiceCurso serviceCurso = new ServiceCurso();
                    int intID = Integer.parseInt(jTextFieldID.getText());
                    try {
                        Curso cursoConsultado = serviceCurso.buscar(intID);
                        if (cursoConsultado == null){
                            JOptionPane.showMessageDialog(null, "El curso consultado no existe");
                        } else {
                            serviceCurso.eliminar(intID);
                            JOptionPane.showMessageDialog(null, "Curso eliminado correctamente");
                        }
                    } catch (ServiceException d) {
                        JOptionPane.showMessageDialog(null, d.getMessage());
                    }
                } catch (NumberFormatException n) {
                    JOptionPane.showMessageDialog(null, "Ingrese un valor numérico en el campo ID");
                }
            }
        });

        jButtonMostrarTodos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ServiceCurso serviceCurso = new ServiceCurso();
                try {
                    ArrayList<Curso> listaCurso = serviceCurso.buscarTodos();
                    if (listaCurso != null) {
                        panel.mostrarReporteCursos();
                    }
                } catch (DAOException s) {
                    System.out.println(s.getMessage());
                }
            }
       });

        jButtonBuscarCurso.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (jTextFieldID != null) {
                    ServiceCurso serviceCurso = new ServiceCurso();
                    int intID = Integer.parseInt(jTextFieldID.getText());
                    try {
                        Curso curso = serviceCurso.buscar(intID);
                        ArrayList<Integer> cursoConsultado = serviceCurso.buscarListaAlumnos(intID);
                        JOptionPane.showMessageDialog(null, "ID: " + curso.getIdCurso() + "\nNombre: " + curso.getNombre() + "\nCupos: " +curso.getCupos() + "\nPrecio: " + curso.getPrecio() + "\nNota de aprobación: " + curso.getNotaAprobacion() + "\nAlumnos en el curso: " + cursoConsultado);
                    } catch (ServiceException | DAOException ex) {
                        throw new RuntimeException(ex);
                    }
                }
            }
        });

        jButtonPasarAInscripcion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrarFormularioInscripcion();            }
        });

        jButtonRecaudacionTotal.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ServiceCurso serviceCurso = new ServiceCurso();
                double recaudacionTotal = 0;
                try {
                    ArrayList<Curso> cursos = serviceCurso.buscarTodos();

                    for (Curso curso : cursos) {
                        int idCurso = curso.getIdCurso();
                        double precio = curso.getPrecio();
                        int cantidadDeAlumnos = serviceCurso.buscarListaAlumnos(idCurso).size();
                        double recaudacionCurso = precio * cantidadDeAlumnos;
                        recaudacionTotal = recaudacionTotal + recaudacionCurso;
                    }
                } catch (DAOException d) {
                JOptionPane.showMessageDialog(null, "Error al calcular la recaudación total.");
                }
                JOptionPane.showMessageDialog(null, "La recaudación total de todos los cursos es de $" + recaudacionTotal);
            }
        });

        jButtonModificarCurso.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int intIDCurso = Integer.parseInt(jTextFieldID.getText());
                int intPrecioCurso = Integer.parseInt(jTextFieldPrecio.getText());
                int intCuposCurso = Integer.parseInt(jTextFieldCupos.getText());
                int intNotaAprobacionCurso = Integer.parseInt(jTextFieldNotaAprobacion.getText());
                String nombreCurso = jTextFieldNombre.getText();
                Curso nuevoCurso = new Curso(intIDCurso, nombreCurso, intCuposCurso,intPrecioCurso,intNotaAprobacionCurso);
                ServiceCurso serviceCurso = new ServiceCurso();
                try {
                    serviceCurso.modificar(intIDCurso, nuevoCurso);
                    JOptionPane.showMessageDialog(null, "Curso modificado con éxito");
                } catch (ServiceException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        jButtonRellenarDatos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (jTextFieldID != null) {
                    ServiceCurso serviceCurso = new ServiceCurso();
                    int intID = Integer.parseInt(jTextFieldID.getText());
                    try {
                        Curso curso = serviceCurso.buscar(intID);
                        jTextFieldNombre.setText(curso.getNombre());
                        jTextFieldCupos.setText(String.valueOf(curso.getCupos()));
                        jTextFieldPrecio.setText(String.valueOf(curso.getPrecio()));
                        jTextFieldNotaAprobacion.setText(String.valueOf(curso.getNotaAprobacion()));
                    } catch (ServiceException ex) {
                        throw new RuntimeException(ex);
                    }
                }
            }
        });

        jButtonRecaudacionDeCurso.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int intIDCurso = Integer.parseInt(jTextFieldID.getText());
                ServiceCurso serviceCurso = new ServiceCurso();
                try {
                    Curso nuevoCurso = serviceCurso.buscar(intIDCurso);
                    double precio = nuevoCurso.getPrecio();
                    int cantidadDeAlumnos = serviceCurso.buscarListaAlumnos(intIDCurso).size();
                    double recaudacionTotal = precio * cantidadDeAlumnos;
                    JOptionPane.showMessageDialog(null, "La recaudación total del curso es de: $" + recaudacionTotal);
                } catch (ServiceException | DAOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

    }
}


