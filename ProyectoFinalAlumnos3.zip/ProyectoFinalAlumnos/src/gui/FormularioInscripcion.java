package gui;

import DAO.DAOException;
import entidades.Alumno;
import entidades.Curso;
import entidades.Escuela;
import service.ServiceAlumno;
import service.ServiceCurso;
import service.ServiceException;
import service.ServiceInscripcion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;

public class FormularioInscripcion extends JPanel {

    private PanelManager panel;
    private ServiceInscripcion serviceInscripcion;
    private JPanel formularioInscripcion;
    private JLabel jLabelIDAlumno;
    private JTextField jTextFieldIDAlumno;
    private JLabel jLabelIDCurso;
    private JTextField jTextFieldIDCurso;
    private JLabel jLabelCalificacion;
    private JTextField jTextFieldCalificacion;
    private JButton jButtonInscribir;
    private JButton jButtonVolverACursos;
    private JButton jButtonAsignarCalificacion;
    private JButton jButtonEliminarInscripcion;
    private JButton jButtonMostrarCalificaciones;

    public FormularioInscripcion(PanelManager panelManager) {
        this.panel = panelManager;
        serviceInscripcion = new ServiceInscripcion();
        armarFormularioInscripcion();
    }

    public void armarFormularioInscripcion(){
        formularioInscripcion = new JPanel();
        serviceInscripcion = new ServiceInscripcion();
        formularioInscripcion.setLayout(new GridLayout(7,2));

        jLabelIDAlumno = new JLabel("ID alumno: ");
        jTextFieldIDAlumno = new JTextField(20);
        jLabelIDCurso = new JLabel("ID curso: ");
        jTextFieldIDCurso = new JTextField(20);
        jLabelCalificacion = new JLabel("Calificacion: ");
        jTextFieldCalificacion = new JTextField(20);
        jButtonInscribir = new JButton("Inscribir alumno");
        jButtonAsignarCalificacion = new JButton("Asignar calificacion");
        jButtonVolverACursos = new JButton("Volver a cursos");
        jButtonEliminarInscripcion = new JButton("Eliminar inscripcion");
        jButtonMostrarCalificaciones = new JButton("Mostrar todas las calificaciones del alumno");

        formularioInscripcion.add(jLabelIDAlumno);
        formularioInscripcion.add(jTextFieldIDAlumno);
        formularioInscripcion.add(jLabelIDCurso);
        formularioInscripcion.add(jTextFieldIDCurso);
        formularioInscripcion.add(jLabelCalificacion);
        formularioInscripcion.add(jTextFieldCalificacion);

        formularioInscripcion.add(jButtonInscribir);
        formularioInscripcion.add(jButtonEliminarInscripcion);
        formularioInscripcion.add(jButtonAsignarCalificacion);
        formularioInscripcion.add(jButtonMostrarCalificaciones);
        formularioInscripcion.add(jButtonVolverACursos);

        setLayout(new BorderLayout());
        add(formularioInscripcion, BorderLayout.CENTER);


        jButtonAsignarCalificacion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ServiceInscripcion serviceInscripcion = new ServiceInscripcion();
                ServiceCurso serviceCurso = new ServiceCurso();
                int intIDAlumno = Integer.parseInt(jTextFieldIDAlumno.getText());
                int intIDCurso = Integer.parseInt(jTextFieldIDCurso.getText());
                int intIDCalificacion = Integer.parseInt(jTextFieldCalificacion.getText());

                serviceInscripcion.actualizarCalificacion(intIDAlumno, intIDCurso, intIDCalificacion);
                JOptionPane.showMessageDialog(null, "Calificación actualizada exitosamente");

                try {
                    Curso curso = serviceCurso.buscar(intIDCurso);
                    int notaAprobacion = curso.getNotaAprobacion();
                    if (intIDCalificacion >= notaAprobacion) {
                        serviceInscripcion.cursoAprobado(intIDAlumno, intIDCurso);
                    } else {
                        serviceInscripcion.cursoDesaprobado(intIDAlumno, intIDCurso);
                    }
                } catch (DAOException | ServiceException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });


        jButtonEliminarInscripcion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ServiceInscripcion serviceInscripcion = new ServiceInscripcion();
                int intIDAlumno = Integer.parseInt(jTextFieldIDAlumno.getText());
                int intIDCurso = Integer.parseInt(jTextFieldIDCurso.getText());
                try {
                    serviceInscripcion.eliminarTablaIntermedia(intIDAlumno, intIDCurso);
                    JOptionPane.showMessageDialog(null, "Inscripcion eliminada exitosamente.");
                } catch (DAOException | SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        jButtonVolverACursos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrarFormularioCursos();
            }
        });


        jButtonInscribir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ServiceAlumno serviceAlumno = new ServiceAlumno();
                ServiceCurso serviceCurso = new ServiceCurso();
                ServiceInscripcion serviceInscripcion = new ServiceInscripcion();
                try {
                    int intIDAlumno = Integer.parseInt(jTextFieldIDAlumno.getText());
                    int intIDCurso = Integer.parseInt(jTextFieldIDCurso.getText());
                    Alumno alumno = serviceAlumno.buscarAlumnoYCursos(intIDAlumno);
                    Curso curso = serviceCurso.buscar(intIDCurso);
                    boolean inscripcion = serviceInscripcion.existeInscripcion(intIDAlumno, intIDCurso);
                    int cantidadDeAlumnosInscriptos = serviceCurso.buscarListaAlumnos(intIDCurso).size();
                    int cupos = curso.getCupos();
                    int cantidadDeCursosDelAlumno = alumno.getListaCursos().size();
                    int cursosAprobados = serviceInscripcion.buscarCursosAprobados(intIDAlumno).size();

                    switch (Escuela.sePuedeInscribir(alumno, curso, inscripcion, cupos, cantidadDeAlumnosInscriptos, cantidadDeCursosDelAlumno, cursosAprobados)) {
                        case 0:
                            JOptionPane.showMessageDialog(null, "El alumno o el curso no existen.");
                            break;
                        case 1:
                            JOptionPane.showMessageDialog(null, "La inscripción ya fue realizada.");
                            break;
                        case 2:
                            JOptionPane.showMessageDialog(null, "No quedan más cupos en ese curso");
                            break;
                        case 3:
                            JOptionPane.showMessageDialog(null, "El alumno superó el límite de cursos.");
                            break;
                        case 4:
                            serviceInscripcion.guardarTablaIntermedia(intIDAlumno, intIDCurso);
                            JOptionPane.showMessageDialog(null, "Alumno inscripto correctamente");
                            break;
                    }
                } catch (DAOException | ServiceException | SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        jButtonMostrarCalificaciones.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ServiceAlumno serviceAlumno = new ServiceAlumno();
                int intID = Integer.parseInt(jTextFieldIDAlumno.getText());
                try {
                    Map<String, Integer> cursosConCalificaciones = serviceAlumno.buscarCalificaciones(intID);
                    JOptionPane.showMessageDialog(null, cursosConCalificaciones);
                } catch (DAOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

    }
}