package gui;

import DAO.DAOAlumno;
import DAO.DAOException;
import entidades.Alumno;
import entidades.Escuela;
import service.ServiceAlumno;
import service.ServiceException;
import service.ServiceInscripcion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class FormularioAlumno extends JPanel {
    PanelManager panel;
    ServiceAlumno serviceAlumno;
    JPanel formularioAlumno;
    JLabel jLabelNombre;
    JLabel jLabelApellido;
    JLabel jLabelID;
    JTextField jTextFieldNombre;
    JTextField jTextFieldApellido;
    JTextField jTextFieldID;
    JButton jButtonGrabar;
    JButton jButtonEliminar;
    JButton jButtonConsultar;
    JButton jButtonConsultarTodos;
    JButton jButtonPasarACursos;
    JButton jButtonModificar;
    JButton jButtonRellenarDatos;

    public FormularioAlumno(PanelManager panel){
        this.panel = panel;
        serviceAlumno = new ServiceAlumno();
        armarFormulario();
    };

    public void armarFormulario() {
        formularioAlumno = new JPanel();
        serviceAlumno = new ServiceAlumno();
        formularioAlumno.setLayout(new GridLayout(7, 2));
        jLabelNombre = new JLabel("Nombre");
        jTextFieldNombre = new JTextField(20);
        jLabelApellido = new JLabel("Apellido");
        jTextFieldApellido = new JTextField(20);
        jLabelID = new JLabel("ID");
        jTextFieldID = new JTextField(8);


        jButtonGrabar = new JButton("Inscribir nuevo alumno");
        jButtonConsultar = new JButton("Consultar alumno existente");
        jButtonEliminar = new JButton("Eliminar alumno");
        jButtonModificar = new JButton("Modificar datos del alumno");
        jButtonConsultarTodos = new JButton("Consultar todos los alumnos de la escuela");
        jButtonPasarACursos = new JButton("Pasar a los cursos");
        jButtonRellenarDatos = new JButton("Rellenar campos del alumno");

        formularioAlumno.add(jLabelNombre);
        formularioAlumno.add(jTextFieldNombre);
        formularioAlumno.add(jLabelApellido);
        formularioAlumno.add(jTextFieldApellido);
        formularioAlumno.add(jLabelID);
        formularioAlumno.add(jTextFieldID);
        formularioAlumno.add(jButtonGrabar);
        formularioAlumno.add(jButtonEliminar);
        formularioAlumno.add(jButtonConsultar);
        formularioAlumno.add(jButtonModificar);
        formularioAlumno.add(jButtonConsultarTodos);
        formularioAlumno.add(jButtonRellenarDatos);
        formularioAlumno.add(jButtonPasarACursos);
        setLayout(new BorderLayout());
        add(formularioAlumno, BorderLayout.CENTER);

        jButtonGrabar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int intID = Integer.parseInt(jTextFieldID.getText());
                    if (Escuela.buscarAlumnoPorId(intID) != null) {
                        JOptionPane.showMessageDialog(null, "El alumno ya existe.");
                    } else {
                        Escuela.crearAlumno(intID, jTextFieldNombre.getText(), jTextFieldApellido.getText());
                        ServiceAlumno serviceAlumno = new ServiceAlumno();
                        try {
                            serviceAlumno.guardar(intID);
                        } catch (ServiceException s) {
                            throw new RuntimeException(s);
                        }
                        JOptionPane.showMessageDialog(null, "Alumno creado correctamente.");
                    }
                } catch (NumberFormatException n) {
                    JOptionPane.showMessageDialog(null, "Ingrese un valor numérico en el campo ID");
                }
            }
        });

        jButtonConsultar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int intID = Integer.parseInt(jTextFieldID.getText());
                    ServiceAlumno serviceAlumno = new ServiceAlumno();
                    try {
                        Alumno alumnoConsultado = serviceAlumno.buscarAlumnoYCursos(intID);
                        if (alumnoConsultado == null){
                            Alumno alumnoSinCursos = serviceAlumno.buscar(intID);
                            if (alumnoSinCursos == null) {
                                JOptionPane.showMessageDialog(null, "El alumno consultado no existe");
                            } else {
                                JOptionPane.showMessageDialog(null, alumnoSinCursos);
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, alumnoConsultado);
                        }
                    } catch (ServiceException d) {
                        JOptionPane.showMessageDialog(null, d.getMessage());
                    }
                } catch (NumberFormatException n) {
                    JOptionPane.showMessageDialog(null, "Ingrese un valor numérico en el campo ID");
                }
            }
        });

        jButtonEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int intID = Integer.parseInt(jTextFieldID.getText());
                    ServiceAlumno serviceAlumno = new ServiceAlumno();
                    try {
                        Alumno alumnoConsultado = serviceAlumno.buscar(intID);
                        if (alumnoConsultado == null){
                            JOptionPane.showMessageDialog(null, "El alumno consultado no existe");
                        } else {
                            try {
                                serviceAlumno.eliminar(intID);
                            } catch (ServiceException s) {
                                JOptionPane.showMessageDialog(null, "Error al eliminar");
                            }
                            JOptionPane.showMessageDialog(null, "Alumno eliminado correctamente");
                        }
                    } catch (ServiceException d) {
                        JOptionPane.showMessageDialog(null, d.getMessage());
                    }
                } catch (NumberFormatException n) {
                    JOptionPane.showMessageDialog(null, "Ingrese un valor numérico en el campo ID");
                }
            }
        });

        jButtonModificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Alumno nuevoAlumno = new Alumno();
                nuevoAlumno.setNombre(jTextFieldNombre.getText());
                nuevoAlumno.setApellido(jTextFieldApellido.getText());
                try {
                    int intID = Integer.parseInt(jTextFieldID.getText());
                    serviceAlumno.modificar(intID, nuevoAlumno);
                } catch (ServiceException ex) {
                    throw new RuntimeException(ex);
                }
                JOptionPane.showMessageDialog(null, "Alumno modificado correctamente.");
            }
        });


        jButtonConsultarTodos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ServiceAlumno serviceAlumno = new ServiceAlumno();
                try {
                    ArrayList<Alumno> listaAlumnos = serviceAlumno.buscarTodos();
                    if (listaAlumnos != null) {
                        panel.mostrarReporteAlumnos();
                    }
                } catch (DAOException s) {
                    JOptionPane.showMessageDialog(null, s.getMessage());
                }
            }
        });

        jButtonPasarACursos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrarFormularioCursos();
            }
        });

        jButtonRellenarDatos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (jTextFieldID != null) {
                    ServiceAlumno serviceAlumno = new ServiceAlumno();
                    int intID = Integer.parseInt(jTextFieldID.getText());
                    try {
                        Alumno alumno = serviceAlumno.buscar(intID);
                        jTextFieldNombre.setText(alumno.getNombre());
                        jTextFieldApellido.setText(alumno.getApellido());
                    } catch (ServiceException ex) {
                        throw new RuntimeException(ex);
                    }
                }
            }
        });
    }
}
