package gui;

import DAO.DAOAlumno;
import DAO.DAOException;
import entidades.Alumno;
import service.ServiceAlumno;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Objects;

public class ReporteAlumnos extends JPanel {
    private PanelManager panelManager;
    private ServiceAlumno serviceAlumno;
    private JPanel pantallaTabla;
    private JTable jTable;
    private DefaultTableModel contenido;
    private JScrollPane scrollPane;
    private JButton jButtonVolver;

    public ReporteAlumnos(PanelManager panel) {
        this.panelManager = panel;
        serviceAlumno = new ServiceAlumno();
        armarTablaReporte();
    }


    public void armarTablaReporte() {
        setLayout(new BorderLayout());
        contenido = new DefaultTableModel();


        jTable = new JTable(contenido);
        pantallaTabla = new JPanel(); // Creo un nuevo panel para la tabla y el botón.
        pantallaTabla.setLayout(new BorderLayout()); // Layout del nuevo panel.
        scrollPane = new JScrollPane(jTable);
        scrollPane.setViewportView(jTable);
        contenido.addColumn("ID");
        contenido.addColumn("Nombre");
        contenido.addColumn("Apellido");
        jButtonVolver = new JButton("Volver");


        pantallaTabla.add(scrollPane, BorderLayout.CENTER); // Agrega la tabla al centro del panel. El scroll pane ya tiene la tabla.
        pantallaTabla.add(jButtonVolver, BorderLayout.SOUTH); // Agrega el botón abajo del panel.

        add(pantallaTabla, BorderLayout.CENTER); // Agrega el panel pantallaTabla al panel 'principal'.

        try {
            ArrayList<Alumno> alumnos = serviceAlumno.buscarTodos();
            for (Alumno alumno : alumnos) {
                Object [] fila = new Object[3];
                fila[0] = alumno.getId();
                fila[1] = alumno.getNombre();
                fila[2] = alumno.getApellido();
                contenido.addRow(fila);
            }
        } catch (DAOException d) {
            JOptionPane.showMessageDialog(null, "Error");
        }

        jButtonVolver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panelManager.mostrarFormularioAlumnos();
            }
        });
    }
}
