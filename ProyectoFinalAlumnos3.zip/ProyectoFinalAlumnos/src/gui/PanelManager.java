package gui;

import DAO.DAOAlumno;
import DAO.DAOCurso;

import javax.swing.*;
import java.awt.*;

public class PanelManager {
    private FormularioAlumno formularioAlumno;
    private ReporteAlumnos reporteAlumnos;
    private FormularioCurso formularioCurso;
    private ReporteCursos reporteCursos;
    private FormularioInscripcion formularioInscripcion;
    JFrame jFrame;

    JPanel panelContenedor;


    public PanelManager() {
        jFrame = new JFrame();
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        formularioAlumno = new FormularioAlumno(this);
        mostrar(formularioAlumno);
        }


    public void mostrar(JPanel panel){
        jFrame.getContentPane().removeAll();
        jFrame.getContentPane().add(BorderLayout.SOUTH, panel);
        jFrame.getContentPane().validate();
        jFrame.getContentPane().repaint();
        jFrame.show();
        jFrame.pack();
    }

    public void mostrarReporteAlumnos() {
            reporteAlumnos = new ReporteAlumnos(this);
            mostrar(reporteAlumnos);
    }

    public void mostrarFormularioAlumnos() {
            formularioAlumno = new FormularioAlumno(this);
            mostrar(formularioAlumno);
    }

    public void mostrarFormularioCursos() {
        formularioCurso = new FormularioCurso(this);
        mostrar(formularioCurso);
    }

    public void mostrarReporteCursos() {
        reporteCursos = new ReporteCursos(this);
        mostrar(reporteCursos);
    }

    public void mostrarFormularioInscripcion() {
        formularioInscripcion = new FormularioInscripcion(this);
        mostrar(formularioInscripcion);
    }


}
