package gui;

import DAO.DAOException;
import entidades.Curso;
import service.ServiceCurso;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ReporteCursos extends JPanel {
    private PanelManager panel;
    private ServiceCurso serviceCurso;
    private JPanel pantallaTabla;
    private JTable jTable;
    private DefaultTableModel contenido;
    private JScrollPane scrollPane;
    private JButton jButtonVolver;

    public ReporteCursos(PanelManager panel) {
        this.panel = panel;
        serviceCurso = new ServiceCurso();
        armarTablaReporte();
    }

    public void armarTablaReporte() {
        setLayout(new BorderLayout());
        contenido = new DefaultTableModel();

        jTable = new JTable(contenido);
        pantallaTabla = new JPanel();
        pantallaTabla.setLayout(new BorderLayout());
        scrollPane = new JScrollPane(jTable);
        scrollPane.setViewportView(jTable);
        contenido.addColumn("ID");
        contenido.addColumn("Nombre");
        contenido.addColumn("Precio");
        contenido.addColumn("Cupos");
        contenido.addColumn("Nota de aprobación");
        jButtonVolver = new JButton("Volver a cursos");

        pantallaTabla.add(scrollPane, BorderLayout.CENTER);
        pantallaTabla.add(jButtonVolver, BorderLayout.SOUTH);


        add(pantallaTabla, BorderLayout.CENTER);

        try {
            ArrayList<Curso> cursos = serviceCurso.buscarTodos();
            for (Curso curso : cursos) {
                Object [] fila = new Object[5];
                fila[0] = curso.getIdCurso();
                fila[1] = curso.getNombre();
                fila[2] = curso.getPrecio();
                fila[3] = curso.getCupos();
                fila[4] = curso.getNotaAprobacion();
                contenido.addRow(fila);
            }
        } catch (DAOException d) {
            JOptionPane.showMessageDialog(null, "Error");
        }

        jButtonVolver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrarFormularioCursos();
            }
        });

    }

}
